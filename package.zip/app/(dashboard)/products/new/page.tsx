import ProductForm from "@/components/products/ProductForm"

const CreateProduct = () => {
  return (
    <ProductForm />
  )
}

export default CreateProduct